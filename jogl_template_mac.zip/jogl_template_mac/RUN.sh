#!/bin/bash

CLASSPATH=$CLASSPATH:./:./jogl-all.jar:gluegen-rt.jar:jogl-all-natives-macosx-universal.jar
java -classpath $CLASSPATH App
