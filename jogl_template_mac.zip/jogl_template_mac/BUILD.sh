#!/bin/bash

javac -classpath ./:./gluegen-rt.jar:./jogl-all.jar:./jogl-all-natives-macosx-universal.jar App.java
